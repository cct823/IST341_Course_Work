''' 1. in iris7, the nested for loops pop out error
    2. Does digit 6 has to apply nested for loop
    3. digits7 line 44 & hw7pr2 line 46 , is that only from 0:64?
    4. hw7pr2 (predict digit, never correct from the model trained in hw6pr2(flower), why?
    5. comments hasnt write yet.
    6.how do i drop na in countlate.py
'''